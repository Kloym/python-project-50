### Hexlet tests and linter status:
[![Actions Status](https://github.com/Kloym/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Kloym/python-project-50/actions)
[![Test Coverage](https://api.codeclimate.com/v1/badges/8c8ec2bddbf4799bf1bc/test_coverage)](https://codeclimate.com/github/Kloym/python-project-50/test_coverage)
![Static Badge](https://img.shields.io/badge/Newbie-orange)
[![Maintainability](https://api.codeclimate.com/v1/badges/8c8ec2bddbf4799bf1bc/maintainability)](https://codeclimate.com/github/Kloym/python-project-50/maintainability)
